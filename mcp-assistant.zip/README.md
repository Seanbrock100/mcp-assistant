# MCP Assistant Project

This project integrates with the Strava API using `stravalib` to fetch and analyze activities.
